package code.name.monkey.musico.util.theme

enum class ThemeMode {
    LIGHT,
    DARK,
    BLACK,
    AUTO
}